import React, {
  Component,
  useState,
  useEffect,
  useCallback,
  useMemo,
} from "react";
import List from "./List";
import Cat from "./Cat.json";
import "./FetchingJson.css";
function FetchingJson() {
  const [data, setData] = useState(Cat);

  const getJsonDataCallBack = useCallback(() => {
    return data;
  }, [data]);

  const getJsonDataMemo = useMemo(() => {
    return data;
  }, [data]);

  return (
    <div className="container">
      <div className="heading">Fetching Json Data</div>
      <div className="inline">
        <div className="con1">
          Using useCallBack
          <List getData={getJsonDataCallBack}></List>
        </div>
        <div className="con2">
          Using useMemo
          <List getData={getJsonDataMemo}></List>
        </div>
      </div>
    </div>
  );
}

export default FetchingJson;
