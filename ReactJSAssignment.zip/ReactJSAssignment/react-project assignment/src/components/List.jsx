import React, { useEffect, useMemo, useState } from "react";

export default function List({ getData }) {
  const [items, setItems] = useState([]);

  useEffect(() => {
    setItems(getData);
    console.log("Updating");
  }, [getData]);

  return items.map((data) => (
    <div key={(data.name, data.age)}>
      <h1>name: {data.name}</h1>
      <p>age: {data.age}</p>
    </div>
  ));
}
